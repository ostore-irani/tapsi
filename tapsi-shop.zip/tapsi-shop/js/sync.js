jQuery(document).ready(function($) {
    $('#start-sync').on('click', function() {
        var $button = $(this);
        var $progress = $('#sync-progress');
        var $progressBar = $('#progress-bar-fill');
        var $syncCount = $('#sync-count');
        var totalSynced = 0;
        
        $button.prop('disabled', true);
        $progress.show();
        
        function syncNextProduct() {
            $.ajax({
                url: tapsiSync.ajaxurl,
                type: 'POST',
                data: {
                    action: 'sync_products',
                    nonce: tapsiSync.nonce
                },
                success: function(response) {
                    if (response.success) {
                        totalSynced += response.synced;
                        $syncCount.text(totalSynced);
                        $progressBar.css('width', '100%');
                        
                        if (response.has_more) {
                            // اگر محصول دیگری هست، به‌روزرسانی بعدی را شروع کن
                            setTimeout(syncNextProduct, 1000);
                        } else {
                            // اگر همه محصولات به‌روزرسانی شدند
                            setTimeout(function() {
                                alert('به‌روزرسانی با موفقیت انجام شد.');
                                $button.prop('disabled', false);
                                $progress.hide();
                                $progressBar.css('width', '0%');
                            }, 1000);
                        }
                    } else {
                        alert('خطا در به‌روزرسانی');
                        $button.prop('disabled', false);
                        $progress.hide();
                    }
                },
                error: function() {
                    alert('خطا در ارتباط با سرور');
                    $button.prop('disabled', false);
                    $progress.hide();
                }
            });
        }
        
        // شروع به‌روزرسانی اولین محصول
        syncNextProduct();
    });
}); 