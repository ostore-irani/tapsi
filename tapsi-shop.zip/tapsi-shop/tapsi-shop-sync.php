<?php
/**
 * Plugin Name: Tapsi Shop Sync
 * Plugin URI: https://seokeywords.ir
 * Description: افزونه همگام‌سازی محصولات ووکامرس با تپسی شاپ
 * Version: 1.2.0
 * Author: seokeywords
 * Author URI: https://seokeywords.ir
 * Text Domain: tapsi-shop-sync
 */

if (!defined('ABSPATH')) {
    exit;
}

class TapsiShopSync {
    private $api_url = 'https://vendorgw.tapsi.shop/web/hub/vendors/v1';
    private $token = 'GhOfcAlkLePQ4+JiRdx4IiesFHrP9Y1IG3xc6oe86zjcAs5cIaxhIYkLILs3BgYM7lAk1+dZS1uIYq8UX0LuJXPzsjyCgeUwfzOKmV25Oa6P65ulCl9rIwbF36kj50gGenWcDxbGRivFQjZh/Zt8+UA80Hux2U3ojhYvBSQhMff7CYU50Ep1U8A+wKIwZL7RmW51Q2HpBem3wUV24J82H6k2camFCzmr7XKxB270DgZs87jlJ77VmjRObqTtiJw4Jm1O5OXGwwxnotMn4ObaFO2TQ8MFF6vkS43RIemqXU8AwIpIjgVKsGmyHCC2vHYYxDPhKZN+9/F2hdR71lA1LObZOIV+gmRyMafsJa5HoLf2qXKcpuM6yisya3B7Bq6V0B+oejh45HwMEbAGZF7Tiyq/WMfNEpFZXIFwqAtYAfLLA+Uz3VttLUD4dZkj7jJNyxFZi3Pj+as8+u28xua62C2ScRYzYgS2jr3LVdn04gQisnWHqhUFCWmM0eeHWe/UP0+gfVeaSvPHGggG5TFkljsReTvhw/3CfjQfH2NUHcoCAb4hFek8EBk2+2En9l6/';

    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('woocommerce_product_options_pricing', array($this, 'add_tapsi_fields'));
        add_action('woocommerce_process_product_meta', array($this, 'save_tapsi_fields'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_ajax_sync_products', array($this, 'ajax_sync_products'));
        
        // اضافه کردن کرون جاب
        add_action('init', array($this, 'schedule_sync'));
        add_action('tapsi_sync_cron', array($this, 'process_sync_cron'));
        
        // اضافه کردن زمان‌بندی 5 دقیقه‌ای
        add_filter('cron_schedules', array($this, 'add_cron_interval'));
    }

    public function add_cron_interval($schedules) {
        $schedules['five_minutes'] = array(
            'interval' => 300,
            'display' => 'هر 5 دقیقه'
        );
        return $schedules;
    }

    public function schedule_sync() {
        if (!wp_next_scheduled('tapsi_sync_cron')) {
            wp_schedule_event(time(), 'five_minutes', 'tapsi_sync_cron');
        }
    }

    public function process_sync_cron() {
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => -1,
            'meta_query' => array(
                array(
                    'key' => '_tapsi_sync_enabled',
                    'value' => 'yes',
                    'compare' => '='
                )
            )
        );

        $products = wc_get_products($args);
        $products_to_sync = array();

        foreach ($products as $product) {
            $tapsi_sku = get_post_meta($product->get_id(), '_tapsi_sku', true);
            if ($tapsi_sku) {
                $products_to_sync[] = array(
                    'id' => $tapsi_sku,
                    'stock' => $product->get_stock_quantity(),
                    'price' => floatval($product->get_regular_price()),
                    'specialprice' => $product->get_sale_price() ? floatval($product->get_sale_price()) : floatval($product->get_regular_price()),
                    'referenceCode' => 'woocommerce_' . $product->get_id()
                );
            }
        }

        if (!empty($products_to_sync)) {
            $data = array('products' => $products_to_sync);
            
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $this->api_url . '/products',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'PUT',
                CURLOPT_POSTFIELDS => json_encode($data),
                CURLOPT_HTTPHEADER => array(
                    'accept: text/plain',
                    'client-name: Swagger on HIT.Hastim.Hub.Endpoints.WebApi',
                    'client-version: 1.0.0.0',
                    'Content-Type: application/json',
                    'TapsiShop.Hub.Authorization: ' . $this->token
                ),
            ));

            $response = curl_exec($curl);
            $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            curl_close($curl);

            // تنظیم منطقه زمانی به تهران
            date_default_timezone_set('Asia/Tehran');
            
            // دریافت زمان محلی
            $local_time = new DateTime('now', new DateTimeZone('Asia/Tehran'));
            
            // ذخیره زمان به صورت شمسی
            $persian_date = wp_date('Y/m/d H:i:s', $local_time->getTimestamp(), new DateTimeZone('Asia/Tehran'));
            update_option('tapsi_last_sync_time', $persian_date);
            update_option('tapsi_last_sync_timestamp', $persian_date );
            
            // لاگ کردن نتیجه
            error_log('Tapsi Shop Sync - HTTP Code: ' . $http_code . ' - Response: ' . $response);
        }
    }

    public function enqueue_scripts() {
        wp_enqueue_script('jquery');
        wp_enqueue_script('tapsi-sync', plugins_url('js/sync.js', __FILE__), array('jquery'), '1.0.0', true);
        wp_localize_script('tapsi-sync', 'tapsiSync', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('tapsi_sync_nonce')
        ));
    }

    public function add_admin_menu() {
        add_menu_page(
            'همگام‌سازی تپسی شاپ',
            'همگام‌سازی تپسی شاپ',
            'manage_options',
            'tapsi-shop-sync',
            array($this, 'admin_page'),
            'dashicons-update',
            56
        );
    }

    public function admin_page() {
        $next_sync = wp_next_scheduled('tapsi_sync_cron');
        $last_sync = get_option('tapsi_last_sync_time');
        
        // تبدیل تاریخ به شمسی
        function convert_to_persian_date($date) {
            if (empty($date)) {
                return 'نامشخص';
            }
            
            // تنظیم منطقه زمانی به تهران
            date_default_timezone_set('Asia/Tehran');
            
            // تبدیل به تاریخ شمسی با استفاده از تابع wp_date
            return wp_date('Y/m/d H:i:s', $date, new DateTimeZone('Asia/Tehran'));
        }
        ?>
        <div class="wrap">
            <h1>همگام‌سازی تپسی شاپ</h1>
            
            <div class="sync-status">
                <p>زمان همگام‌سازی بعدی: <?php echo convert_to_persian_date($next_sync); ?></p>
                <p>آخرین همگام‌سازی: <?php echo $last_sync ?: 'نامشخص'; ?></p>
                <button id="start-sync" class="button button-primary">به‌روزرسانی قیمت محصولات</button>
                <div id="sync-progress" style="display: none;">
                    <p>در حال به‌روزرسانی... <span id="sync-count">0</span> محصول</p>
                    <div class="progress-bar" style="width: 100%; height: 20px; background: #f0f0f0;">
                        <div id="progress-bar-fill" style="width: 0%; height: 100%; background: #0073aa;"></div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    public function add_tapsi_fields() {
        global $woocommerce, $post;
        
        echo '<div class="options_group">';
        
        woocommerce_wp_checkbox(array(
            'id' => '_tapsi_sync_enabled',
            'label' => 'همگام‌سازی با تپسی شاپ',
            'desc_tip' => true,
            'description' => 'با فعال کردن این گزینه، این محصول با تپسی شاپ همگام‌سازی می‌شود'
        ));
        
        woocommerce_wp_text_input(array(
            'id' => '_tapsi_sku',
            'label' => 'شناسه محصول در تپسی شاپ',
            'desc_tip' => true,
            'description' => 'شناسه محصول در تپسی شاپ را وارد کنید'
        ));
        
        echo '</div>';
    }

    public function save_tapsi_fields($post_id) {
        $sync_enabled = isset($_POST['_tapsi_sync_enabled']) ? 'yes' : 'no';
        update_post_meta($post_id, '_tapsi_sync_enabled', $sync_enabled);

        $tapsi_sku = isset($_POST['_tapsi_sku']) ? $_POST['_tapsi_sku'] : '';
        if (!empty($tapsi_sku)) {
            update_post_meta($post_id, '_tapsi_sku', esc_attr($tapsi_sku));
        }
    }

    public function ajax_sync_products() {
        check_ajax_referer('tapsi_sync_nonce', 'nonce');

        $args = array(
            'post_type' => 'product',
            'posts_per_page' => -1,
            'meta_query' => array(
                array(
                    'key' => '_tapsi_sync_enabled',
                    'value' => 'yes',
                    'compare' => '='
                )
            )
        );

        $products = wc_get_products($args);
        $products_to_sync = array();

        foreach ($products as $product) {
            $tapsi_sku = get_post_meta($product->get_id(), '_tapsi_sku', true);
            if ($tapsi_sku) {
                $products_to_sync[] = array(
                    'id' => $tapsi_sku,
                    'stock' => $product->get_stock_quantity(),
                    'price' => floatval($product->get_regular_price()),
                    'specialprice' => $product->get_sale_price() ? floatval($product->get_sale_price()) : floatval($product->get_regular_price()),
                    'referenceCode' => 'woocommerce_' . $product->get_id()
                );
            }
        }

        if (!empty($products_to_sync)) {
            $data = array('products' => $products_to_sync);
            
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $this->api_url . '/products',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'PUT',
                CURLOPT_POSTFIELDS => json_encode($data),
                CURLOPT_HTTPHEADER => array(
                    'accept: text/plain',
                    'client-name: Swagger on HIT.Hastim.Hub.Endpoints.WebApi',
                    'client-version: 1.0.0.0',
                    'Content-Type: application/json',
                    'TapsiShop.Hub.Authorization: ' . $this->token
                ),
            ));
 
            $response = curl_exec($curl);
            curl_close($curl);
        }

        wp_send_json(array(
            'success' => true,
            'synced' => count($products_to_sync)
        ));
    }
}

$tapsi_shop_sync = new TapsiShopSync(); 